import Employee

e1 = Employee.Employee(101,"Aishwarya",20000)
#e1.displayDetails()

e2 = Employee.Employee(102,"Sonal",25000)
#e2.displayDetails()

e3 = Employee.Employee(103,"Priyanka",30000)
#e3.displayDetails()

l1 = []

l1.append(e1)
l1.append(e2)
l1.append(e3)

f = open("Emp1.txt",'w')

for i in l1:
    f.write(str(i.empId)+","+str(i.empName)+","+str(i.empSalary)+"\n")
  

print("Written in file successfully..")
f.close()


