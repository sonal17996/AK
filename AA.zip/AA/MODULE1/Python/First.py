# This is my first Python program

print("Hello World")

name = input("Enter your name: ")

number = int(input("Enter a number: "))
#print("My name is:",name,"\nMy age is:",(age+1))
#print(type(age))

if number==0:
    print("Zero not allowed")

elif number%2==0:
        print("Number is even")

else:
     print("Number is odd")

print("My name is {0}, age is {1}, I'm {0}".format(name,number))
