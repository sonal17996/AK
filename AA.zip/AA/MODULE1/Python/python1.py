Python 3.3.2 (v3.3.2:d047928ae3f6, May 16 2013, 00:03:43) [MSC v.1600 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> print("Hello World")
Hello World
>>> print("Hello"," ","World")
Hello   World
>>> print('Hello')
Hello
>>> print("Hello","World")
Hello World
>>> n1 = 10
>>> n1
10
>>> print(n1)
10
>>> s1 = "Hello World"
>>> s1
'Hello World'
>>> s1+n1
Traceback (most recent call last):
  File "<pyshell#9>", line 1, in <module>
    s1+n1
TypeError: Can't convert 'int' object to str implicitly
>>> print(s1,n1)
Hello World 10
>>> print(s1,n1,sep='\n')
Hello World
10
>>> n1=1
>>> n1
1
>>> nx
Traceback (most recent call last):
  File "<pyshell#14>", line 1, in <module>
    nx
NameError: name 'nx' is not defined
>>> nx=0
>>> type(nx)
<class 'int'>
>>> type(s1)
<class 'str'>
>>> type(n1)
<class 'int'>
>>> help(equals)
Traceback (most recent call last):
  File "<pyshell#19>", line 1, in <module>
    help(equals)
NameError: name 'equals' is not defined
>>> help(equal)
Traceback (most recent call last):
  File "<pyshell#20>", line 1, in <module>
    help(equal)
NameError: name 'equal' is not defined
>>> help(type)
Help on class type in module builtins:

class type(object)
 |  type(object) -> the object's type
 |  type(name, bases, dict) -> a new type
 |  
 |  Methods defined here:
 |  
 |  __call__(...)
 |      x.__call__(...) <==> x(...)
 |  
 |  __delattr__(...)
 |      x.__delattr__('name') <==> del x.name
 |  
 |  __dir__(...)
 |      __dir__() -> list
 |      specialized __dir__ implementation for types
 |  
 |  __getattribute__(...)
 |      x.__getattribute__('name') <==> x.name
 |  
 |  __init__(...)
 |      x.__init__(...) initializes x; see help(type(x)) for signature
 |  
 |  __instancecheck__(...)
 |      __instancecheck__() -> bool
 |      check if an object is an instance
 |  
 |  __prepare__(...)
 |      __prepare__() -> dict
 |      used to create the namespace for the class statement
 |  
 |  __repr__(...)
 |      x.__repr__() <==> repr(x)
 |  
 |  __setattr__(...)
 |      x.__setattr__('name', value) <==> x.name = value
 |  
 |  __sizeof__(...)
 |      __sizeof__() -> int
 |      return memory consumption of the type object
 |  
 |  __subclasscheck__(...)
 |      __subclasscheck__() -> bool
 |      check if a class is a subclass
 |  
 |  __subclasses__(...)
 |      __subclasses__() -> list of immediate subclasses
 |  
 |  mro(...)
 |      mro() -> list
 |      return a type's method resolution order
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __abstractmethods__
 |  
 |  __base__
 |  
 |  __bases__
 |  
 |  __basicsize__
 |  
 |  __dict__
 |  
 |  __dictoffset__
 |  
 |  __flags__
 |  
 |  __itemsize__
 |  
 |  __mro__
 |  
 |  __weakrefoffset__
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  __new__ = <built-in method __new__ of type object>
 |      T.__new__(S, ...) -> a new object with type S, a subtype of T

>>> id(n1)
505910864
>>> n2=n1
>>> n2
1
>>> id(n2)
505910864
>>> n1==n2
True
>>> n1 is n2
True
>>> l1 = [1,2,3]
>>> l1
[1, 2, 3]
>>> type(l1)
<class 'list'>
>>> id(l1)
49469760
>>> l2 = l1
>>> id(l2)
49469760
>>> l2==l1
True
>>> l2 is l1
True
>>> l3 = list(l1)
>>> id(l3)
49471200
>>> l3
[1, 2, 3]
>>> l3==l1
True
>>> l3 is l1
False
>>> x=True
>>> type(x)
<class 'bool'>
>>> 12**2
144
>>> 12//2
6
>>> 12/2
6.0
>>> n1+=2
>>> n1
3
>>> id(n1)
505910896
>>> ================================ RESTART ================================
>>> 
Hello World
>>> ================================ RESTART ================================
>>> 
Hello World
Enter your name: Aishwarya
My name is: Aishwarya
>>> ================================ RESTART ================================
>>> 
Hello World
Enter your name: Aishwarya
My name is: Aishwarya
Enter your age: 21
My name is: 21
>>> ================================ RESTART ================================
>>> 
Hello World
Enter your name: Aishwarya

Enter your age: 2
My name is: Aishwarya 
My age is: 2
>>> ================================ RESTART ================================
>>> 
Hello World
Enter your name: Aishwarya

Enter your age: 21
Traceback (most recent call last):
  File "D:/First.py", line 9, in <module>
    print("My name is:",name,"\nMy age is:",(age+1))
TypeError: Can't convert 'int' object to str implicitly
>>> ================================ RESTART ================================
>>> 
Hello World
Enter your name: A

Enter your age: 21
My name is: A 
My age is: 22
<class 'int'>
>>> ================================ RESTART ================================
>>> 
Hello World
Enter your name: A
Enter a number: 22
Number is even
>>> ================================ RESTART ================================
>>> 
Hello World
Enter your name: A
Enter a number: 22
Number is even
>>> ================================ RESTART ================================
>>> 
Hello World
Enter your name: A
Enter a number: 0
Zero not allowed
>>> ================================ RESTART ================================
>>> 
Hello World
Enter your name: a
Enter a number: 0
Zero not allowed
>>> math.pi
Traceback (most recent call last):
  File "<pyshell#49>", line 1, in <module>
    math.pi
NameError: name 'math' is not defined
>>> import math
>>> math.pi
3.141592653589793
>>> math.sqrt(4)
2.0
>>> math.radians(90)
1.5707963267948966
>>> s1="Hello"
>>> n1=10
>>> s2=str(n1)+s1
>>> s2
'10Hello'
>>> s1="Hello Worldd"
>>> str(count(s1))
Traceback (most recent call last):
  File "<pyshell#59>", line 1, in <module>
    str(count(s1))
NameError: name 'count' is not defined
>>> str.count(s1)
Traceback (most recent call last):
  File "<pyshell#60>", line 1, in <module>
    str.count(s1)
TypeError: count() takes at least 1 argument (0 given)
>>> s1="aaaabbb"
>>> s1.count('a',0,5)
4
>>> s1.count
<built-in method count of str object at 0x02FFF2A0>
>>> s1.count('a')
4
>>> s1='a'
>>> s2='b'
>>> s1.join(s2)
'b'
>>> s1
'a'
>>> s='ak'
>>> s=s.join('aa')
>>> s
'aaka'
>>> help(str)
Help on class str in module builtins:

class str(object)
 |  str(object='') -> str
 |  str(bytes_or_buffer[, encoding[, errors]]) -> str
 |  
 |  Create a new string object from the given object. If encoding or
 |  errors is specified, then the object must expose a data buffer
 |  that will be decoded using the given encoding and error handler.
 |  Otherwise, returns the result of object.__str__() (if defined)
 |  or repr(object).
 |  encoding defaults to sys.getdefaultencoding().
 |  errors defaults to 'strict'.
 |  
 |  Methods defined here:
 |  
 |  __add__(...)
 |      x.__add__(y) <==> x+y
 |  
 |  __contains__(...)
 |      x.__contains__(y) <==> y in x
 |  
 |  __eq__(...)
 |      x.__eq__(y) <==> x==y
 |  
 |  __format__(...)
 |      S.__format__(format_spec) -> str
 |      
 |      Return a formatted version of S as described by format_spec.
 |  
 |  __ge__(...)
 |      x.__ge__(y) <==> x>=y
 |  
 |  __getattribute__(...)
 |      x.__getattribute__('name') <==> x.name
 |  
 |  __getitem__(...)
 |      x.__getitem__(y) <==> x[y]
 |  
 |  __getnewargs__(...)
 |  
 |  __gt__(...)
 |      x.__gt__(y) <==> x>y
 |  
 |  __hash__(...)
 |      x.__hash__() <==> hash(x)
 |  
 |  __iter__(...)
 |      x.__iter__() <==> iter(x)
 |  
 |  __le__(...)
 |      x.__le__(y) <==> x<=y
 |  
 |  __len__(...)
 |      x.__len__() <==> len(x)
 |  
 |  __lt__(...)
 |      x.__lt__(y) <==> x<y
 |  
 |  __mod__(...)
 |      x.__mod__(y) <==> x%y
 |  
 |  __mul__(...)
 |      x.__mul__(n) <==> x*n
 |  
 |  __ne__(...)
 |      x.__ne__(y) <==> x!=y
 |  
 |  __repr__(...)
 |      x.__repr__() <==> repr(x)
 |  
 |  __rmod__(...)
 |      x.__rmod__(y) <==> y%x
 |  
 |  __rmul__(...)
 |      x.__rmul__(n) <==> n*x
 |  
 |  __sizeof__(...)
 |      S.__sizeof__() -> size of S in memory, in bytes
 |  
 |  __str__(...)
 |      x.__str__() <==> str(x)
 |  
 |  capitalize(...)
 |      S.capitalize() -> str
 |      
 |      Return a capitalized version of S, i.e. make the first character
 |      have upper case and the rest lower case.
 |  
 |  casefold(...)
 |      S.casefold() -> str
 |      
 |      Return a version of S suitable for caseless comparisons.
 |  
 |  center(...)
 |      S.center(width[, fillchar]) -> str
 |      
 |      Return S centered in a string of length width. Padding is
 |      done using the specified fill character (default is a space)
 |  
 |  count(...)
 |      S.count(sub[, start[, end]]) -> int
 |      
 |      Return the number of non-overlapping occurrences of substring sub in
 |      string S[start:end].  Optional arguments start and end are
 |      interpreted as in slice notation.
 |  
 |  encode(...)
 |      S.encode(encoding='utf-8', errors='strict') -> bytes
 |      
 |      Encode S using the codec registered for encoding. Default encoding
 |      is 'utf-8'. errors may be given to set a different error
 |      handling scheme. Default is 'strict' meaning that encoding errors raise
 |      a UnicodeEncodeError. Other possible values are 'ignore', 'replace' and
 |      'xmlcharrefreplace' as well as any other name registered with
 |      codecs.register_error that can handle UnicodeEncodeErrors.
 |  
 |  endswith(...)
 |      S.endswith(suffix[, start[, end]]) -> bool
 |      
 |      Return True if S ends with the specified suffix, False otherwise.
 |      With optional start, test S beginning at that position.
 |      With optional end, stop comparing S at that position.
 |      suffix can also be a tuple of strings to try.
 |  
 |  expandtabs(...)
 |      S.expandtabs([tabsize]) -> str
 |      
 |      Return a copy of S where all tab characters are expanded using spaces.
 |      If tabsize is not given, a tab size of 8 characters is assumed.
 |  
 |  find(...)
 |      S.find(sub[, start[, end]]) -> int
 |      
 |      Return the lowest index in S where substring sub is found,
 |      such that sub is contained within S[start:end].  Optional
 |      arguments start and end are interpreted as in slice notation.
 |      
 |      Return -1 on failure.
 |  
 |  format(...)
 |      S.format(*args, **kwargs) -> str
 |      
 |      Return a formatted version of S, using substitutions from args and kwargs.
 |      The substitutions are identified by braces ('{' and '}').
 |  
 |  format_map(...)
 |      S.format_map(mapping) -> str
 |      
 |      Return a formatted version of S, using substitutions from mapping.
 |      The substitutions are identified by braces ('{' and '}').
 |  
 |  index(...)
 |      S.index(sub[, start[, end]]) -> int
 |      
 |      Like S.find() but raise ValueError when the substring is not found.
 |  
 |  isalnum(...)
 |      S.isalnum() -> bool
 |      
 |      Return True if all characters in S are alphanumeric
 |      and there is at least one character in S, False otherwise.
 |  
 |  isalpha(...)
 |      S.isalpha() -> bool
 |      
 |      Return True if all characters in S are alphabetic
 |      and there is at least one character in S, False otherwise.
 |  
 |  isdecimal(...)
 |      S.isdecimal() -> bool
 |      
 |      Return True if there are only decimal characters in S,
 |      False otherwise.
 |  
 |  isdigit(...)
 |      S.isdigit() -> bool
 |      
 |      Return True if all characters in S are digits
 |      and there is at least one character in S, False otherwise.
 |  
 |  isidentifier(...)
 |      S.isidentifier() -> bool
 |      
 |      Return True if S is a valid identifier according
 |      to the language definition.
 |      
 |      Use keyword.iskeyword() to test for reserved identifiers
 |      such as "def" and "class".
 |  
 |  islower(...)
 |      S.islower() -> bool
 |      
 |      Return True if all cased characters in S are lowercase and there is
 |      at least one cased character in S, False otherwise.
 |  
 |  isnumeric(...)
 |      S.isnumeric() -> bool
 |      
 |      Return True if there are only numeric characters in S,
 |      False otherwise.
 |  
 |  isprintable(...)
 |      S.isprintable() -> bool
 |      
 |      Return True if all characters in S are considered
 |      printable in repr() or S is empty, False otherwise.
 |  
 |  isspace(...)
 |      S.isspace() -> bool
 |      
 |      Return True if all characters in S are whitespace
 |      and there is at least one character in S, False otherwise.
 |  
 |  istitle(...)
 |      S.istitle() -> bool
 |      
 |      Return True if S is a titlecased string and there is at least one
 |      character in S, i.e. upper- and titlecase characters may only
 |      follow uncased characters and lowercase characters only cased ones.
 |      Return False otherwise.
 |  
 |  isupper(...)
 |      S.isupper() -> bool
 |      
 |      Return True if all cased characters in S are uppercase and there is
 |      at least one cased character in S, False otherwise.
 |  
 |  join(...)
 |      S.join(iterable) -> str
 |      
 |      Return a string which is the concatenation of the strings in the
 |      iterable.  The separator between elements is S.
 |  
 |  ljust(...)
 |      S.ljust(width[, fillchar]) -> str
 |      
 |      Return S left-justified in a Unicode string of length width. Padding is
 |      done using the specified fill character (default is a space).
 |  
 |  lower(...)
 |      S.lower() -> str
 |      
 |      Return a copy of the string S converted to lowercase.
 |  
 |  lstrip(...)
 |      S.lstrip([chars]) -> str
 |      
 |      Return a copy of the string S with leading whitespace removed.
 |      If chars is given and not None, remove characters in chars instead.
 |  
 |  partition(...)
 |      S.partition(sep) -> (head, sep, tail)
 |      
 |      Search for the separator sep in S, and return the part before it,
 |      the separator itself, and the part after it.  If the separator is not
 |      found, return S and two empty strings.
 |  
 |  replace(...)
 |      S.replace(old, new[, count]) -> str
 |      
 |      Return a copy of S with all occurrences of substring
 |      old replaced by new.  If the optional argument count is
 |      given, only the first count occurrences are replaced.
 |  
 |  rfind(...)
 |      S.rfind(sub[, start[, end]]) -> int
 |      
 |      Return the highest index in S where substring sub is found,
 |      such that sub is contained within S[start:end].  Optional
 |      arguments start and end are interpreted as in slice notation.
 |      
 |      Return -1 on failure.
 |  
 |  rindex(...)
 |      S.rindex(sub[, start[, end]]) -> int
 |      
 |      Like S.rfind() but raise ValueError when the substring is not found.
 |  
 |  rjust(...)
 |      S.rjust(width[, fillchar]) -> str
 |      
 |      Return S right-justified in a string of length width. Padding is
 |      done using the specified fill character (default is a space).
 |  
 |  rpartition(...)
 |      S.rpartition(sep) -> (head, sep, tail)
 |      
 |      Search for the separator sep in S, starting at the end of S, and return
 |      the part before it, the separator itself, and the part after it.  If the
 |      separator is not found, return two empty strings and S.
 |  
 |  rsplit(...)
 |      S.rsplit(sep=None, maxsplit=-1) -> list of strings
 |      
 |      Return a list of the words in S, using sep as the
 |      delimiter string, starting at the end of the string and
 |      working to the front.  If maxsplit is given, at most maxsplit
 |      splits are done. If sep is not specified, any whitespace string
 |      is a separator.
 |  
 |  rstrip(...)
 |      S.rstrip([chars]) -> str
 |      
 |      Return a copy of the string S with trailing whitespace removed.
 |      If chars is given and not None, remove characters in chars instead.
 |  
 |  split(...)
 |      S.split(sep=None, maxsplit=-1) -> list of strings
 |      
 |      Return a list of the words in S, using sep as the
 |      delimiter string.  If maxsplit is given, at most maxsplit
 |      splits are done. If sep is not specified or is None, any
 |      whitespace string is a separator and empty strings are
 |      removed from the result.
 |  
 |  splitlines(...)
 |      S.splitlines([keepends]) -> list of strings
 |      
 |      Return a list of the lines in S, breaking at line boundaries.
 |      Line breaks are not included in the resulting list unless keepends
 |      is given and true.
 |  
 |  startswith(...)
 |      S.startswith(prefix[, start[, end]]) -> bool
 |      
 |      Return True if S starts with the specified prefix, False otherwise.
 |      With optional start, test S beginning at that position.
 |      With optional end, stop comparing S at that position.
 |      prefix can also be a tuple of strings to try.
 |  
 |  strip(...)
 |      S.strip([chars]) -> str
 |      
 |      Return a copy of the string S with leading and trailing
 |      whitespace removed.
 |      If chars is given and not None, remove characters in chars instead.
 |  
 |  swapcase(...)
 |      S.swapcase() -> str
 |      
 |      Return a copy of S with uppercase characters converted to lowercase
 |      and vice versa.
 |  
 |  title(...)
 |      S.title() -> str
 |      
 |      Return a titlecased version of S, i.e. words start with title case
 |      characters, all remaining cased characters have lower case.
 |  
 |  translate(...)
 |      S.translate(table) -> str
 |      
 |      Return a copy of the string S, where all characters have been mapped
 |      through the given translation table, which must be a mapping of
 |      Unicode ordinals to Unicode ordinals, strings, or None.
 |      Unmapped characters are left untouched. Characters mapped to None
 |      are deleted.
 |  
 |  upper(...)
 |      S.upper() -> str
 |      
 |      Return a copy of S converted to uppercase.
 |  
 |  zfill(...)
 |      S.zfill(width) -> str
 |      
 |      Pad a numeric string S with zeros on the left, to fill a field
 |      of the specified width. The string S is never truncated.
 |  
 |  ----------------------------------------------------------------------
 |  Static methods defined here:
 |  
 |  maketrans(...)
 |      str.maketrans(x[, y[, z]]) -> dict (static method)
 |      
 |      Return a translation table usable for str.translate().
 |      If there is only one argument, it must be a dictionary mapping Unicode
 |      ordinals (integers) or characters to Unicode ordinals, strings or None.
 |      Character keys will be then converted to ordinals.
 |      If there are two arguments, they must be strings of equal length, and
 |      in the resulting dictionary, each character in x will be mapped to the
 |      character at the same position in y. If there is a third argument, it
 |      must be a string, whose characters will be mapped to None in the result.
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  __new__ = <built-in method __new__ of type object>
 |      T.__new__(S, ...) -> a new object with type S, a subtype of T

>>> s='aishwarya'
>>> s.split(sep='\n',maxsplit=-1)
['aishwarya']
>>> s
'aishwarya'
>>> s.split(sep='\n')
['aishwarya']
>>> s=aishwarya k
SyntaxError: invalid syntax
>>> s='aishwarya k'
>>> s.split(sep=' ')
['aishwarya', 'k']
>>> s.replace('war','raw')
'aishrawya k'
>>> 'p' in 'apple'
True
>>> 'i' in 'apple'
False
>>> 'p' not in 'apple'
False
>>> ================================ RESTART ================================
>>> 
Hello World
Enter your name: aishwarya
Enter a number: 33
Number is odd
My name is aishwarya, age is 33, I'm aishwarya
>>> x=None
>>> x
>>> id(x)
505672132
>>> l = [1,'a',2.3,'akk',4,5]
>>> l
[1, 'a', 2.3, 'akk', 4, 5]
>>> l[4-2]
2.3
>>> l[2-4]
4
>>> x[1:3]
Traceback (most recent call last):
  File "<pyshell#91>", line 1, in <module>
    x[1:3]
TypeError: 'NoneType' object is not subscriptable
>>> l[1:3]
['a', 2.3]
>>> l[:3]
[1, 'a', 2.3]
>>> l[:]
[1, 'a', 2.3, 'akk', 4, 5]
>>> l[3:]
['akk', 4, 5]
>>> l.append('hi')
>>> l
[1, 'a', 2.3, 'akk', 4, 5, 'hi']
>>> len(l)
7
>>> s1="hello"
>>> len(s1)
5
>>> id(l)
47851800
>>> l.append('abc')
>>> l
[1, 'a', 2.3, 'akk', 4, 5, 'hi', 'abc']
>>> id(l)
47851800
>>> l.pop()
'abc'
>>> l
[1, 'a', 2.3, 'akk', 4, 5, 'hi']
>>> l.push('abc')
Traceback (most recent call last):
  File "<pyshell#107>", line 1, in <module>
    l.push('abc')
AttributeError: 'list' object has no attribute 'push'
>>> help(list)
Help on class list in module builtins:

class list(object)
 |  list() -> new empty list
 |  list(iterable) -> new list initialized from iterable's items
 |  
 |  Methods defined here:
 |  
 |  __add__(...)
 |      x.__add__(y) <==> x+y
 |  
 |  __contains__(...)
 |      x.__contains__(y) <==> y in x
 |  
 |  __delitem__(...)
 |      x.__delitem__(y) <==> del x[y]
 |  
 |  __eq__(...)
 |      x.__eq__(y) <==> x==y
 |  
 |  __ge__(...)
 |      x.__ge__(y) <==> x>=y
 |  
 |  __getattribute__(...)
 |      x.__getattribute__('name') <==> x.name
 |  
 |  __getitem__(...)
 |      x.__getitem__(y) <==> x[y]
 |  
 |  __gt__(...)
 |      x.__gt__(y) <==> x>y
 |  
 |  __iadd__(...)
 |      x.__iadd__(y) <==> x+=y
 |  
 |  __imul__(...)
 |      x.__imul__(y) <==> x*=y
 |  
 |  __init__(...)
 |      x.__init__(...) initializes x; see help(type(x)) for signature
 |  
 |  __iter__(...)
 |      x.__iter__() <==> iter(x)
 |  
 |  __le__(...)
 |      x.__le__(y) <==> x<=y
 |  
 |  __len__(...)
 |      x.__len__() <==> len(x)
 |  
 |  __lt__(...)
 |      x.__lt__(y) <==> x<y
 |  
 |  __mul__(...)
 |      x.__mul__(n) <==> x*n
 |  
 |  __ne__(...)
 |      x.__ne__(y) <==> x!=y
 |  
 |  __repr__(...)
 |      x.__repr__() <==> repr(x)
 |  
 |  __reversed__(...)
 |      L.__reversed__() -- return a reverse iterator over the list
 |  
 |  __rmul__(...)
 |      x.__rmul__(n) <==> n*x
 |  
 |  __setitem__(...)
 |      x.__setitem__(i, y) <==> x[i]=y
 |  
 |  __sizeof__(...)
 |      L.__sizeof__() -- size of L in memory, in bytes
 |  
 |  append(...)
 |      L.append(object) -> None -- append object to end
 |  
 |  clear(...)
 |      L.clear() -> None -- remove all items from L
 |  
 |  copy(...)
 |      L.copy() -> list -- a shallow copy of L
 |  
 |  count(...)
 |      L.count(value) -> integer -- return number of occurrences of value
 |  
 |  extend(...)
 |      L.extend(iterable) -> None -- extend list by appending elements from the iterable
 |  
 |  index(...)
 |      L.index(value, [start, [stop]]) -> integer -- return first index of value.
 |      Raises ValueError if the value is not present.
 |  
 |  insert(...)
 |      L.insert(index, object) -- insert object before index
 |  
 |  pop(...)
 |      L.pop([index]) -> item -- remove and return item at index (default last).
 |      Raises IndexError if list is empty or index is out of range.
 |  
 |  remove(...)
 |      L.remove(value) -> None -- remove first occurrence of value.
 |      Raises ValueError if the value is not present.
 |  
 |  reverse(...)
 |      L.reverse() -- reverse *IN PLACE*
 |  
 |  sort(...)
 |      L.sort(key=None, reverse=False) -> None -- stable sort *IN PLACE*
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  __hash__ = None
 |  
 |  __new__ = <built-in method __new__ of type object>
 |      T.__new__(S, ...) -> a new object with type S, a subtype of T

>>> n1=20
>>> n1
20
>>> del(n1)
>>> n1
Traceback (most recent call last):
  File "<pyshell#112>", line 1, in <module>
    n1
NameError: name 'n1' is not defined
>>> l.remove('a')
>>> l
[1, 2.3, 'akk', 4, 5, 'hi']
>>> l1=[6,4,9,2,8,1]
>>> s1.sort()
Traceback (most recent call last):
  File "<pyshell#116>", line 1, in <module>
    s1.sort()
AttributeError: 'str' object has no attribute 'sort'
>>> l1.sort()
>>> l1
[1, 2, 4, 6, 8, 9]
>>> l1.reverse()
>>> l1
[9, 8, 6, 4, 2, 1]
>>> id(l1)
48673336
>>> l2 = [1,2,3,[4,5,6]]
>>> l2[3][1]
5
>>> l2[3][1]=10
>>> l2
[1, 2, 3, [4, 10, 6]]
>>> l3 = [l1,l2,5,6]
>>> l3
[[9, 8, 6, 4, 2, 1], [1, 2, 3, [4, 10, 6]], 5, 6]
>>> l4=['s','k','y']
>>> l4.sort()
>>> l4
['k', 's', 'y']
>>> l3+l4
[[9, 8, 6, 4, 2, 1], [1, 2, 3, [4, 10, 6]], 5, 6, 'k', 's', 'y']
>>> l4*2
['k', 's', 'y', 'k', 's', 'y']
>>> l5=l4+[1,2,3]
>>> l5
['k', 's', 'y', 1, 2, 3]
>>> l5.del(3)
SyntaxError: invalid syntax
>>> del(l5)
>>> l5
Traceback (most recent call last):
  File "<pyshell#137>", line 1, in <module>
    l5
NameError: name 'l5' is not defined
>>> clear(l4)
Traceback (most recent call last):
  File "<pyshell#138>", line 1, in <module>
    clear(l4)
NameError: name 'clear' is not defined
>>> l4.clear
<built-in method clear of list object at 0x02E6BCD8>
>>> l4.clear()
>>> l4
[]
>>> type(l5)
Traceback (most recent call last):
  File "<pyshell#142>", line 1, in <module>
    type(l5)
NameError: name 'l5' is not defined
>>> type(l4)
<class 'list'>
>>> len(l4)
0
>>> id(l4)
48676056
>>> l6 = [1]
>>> l6
[1]
>>> type(l6)
<class 'list'>
>>> t = ('a','b','c')
>>> t
('a', 'b', 'c')
>>> t = ('a')
>>> t
'a'
>>> type(t)
<class 'str'>
>>> t1=(1,2,3)
>>> type(t1)
<class 'tuple'>
>>> t = ('a',)
>>> type(t)
<class 'tuple'>
>>> 
len(t1)
3
>>> len(t)
1
>>> id(t)
48143696
>>> help(tuple)
Help on class tuple in module builtins:

class tuple(object)
 |  tuple() -> empty tuple
 |  tuple(iterable) -> tuple initialized from iterable's items
 |  
 |  If the argument is a tuple, the return value is the same object.
 |  
 |  Methods defined here:
 |  
 |  __add__(...)
 |      x.__add__(y) <==> x+y
 |  
 |  __contains__(...)
 |      x.__contains__(y) <==> y in x
 |  
 |  __eq__(...)
 |      x.__eq__(y) <==> x==y
 |  
 |  __ge__(...)
 |      x.__ge__(y) <==> x>=y
 |  
 |  __getattribute__(...)
 |      x.__getattribute__('name') <==> x.name
 |  
 |  __getitem__(...)
 |      x.__getitem__(y) <==> x[y]
 |  
 |  __getnewargs__(...)
 |  
 |  __gt__(...)
 |      x.__gt__(y) <==> x>y
 |  
 |  __hash__(...)
 |      x.__hash__() <==> hash(x)
 |  
 |  __iter__(...)
 |      x.__iter__() <==> iter(x)
 |  
 |  __le__(...)
 |      x.__le__(y) <==> x<=y
 |  
 |  __len__(...)
 |      x.__len__() <==> len(x)
 |  
 |  __lt__(...)
 |      x.__lt__(y) <==> x<y
 |  
 |  __mul__(...)
 |      x.__mul__(n) <==> x*n
 |  
 |  __ne__(...)
 |      x.__ne__(y) <==> x!=y
 |  
 |  __repr__(...)
 |      x.__repr__() <==> repr(x)
 |  
 |  __rmul__(...)
 |      x.__rmul__(n) <==> n*x
 |  
 |  __sizeof__(...)
 |      T.__sizeof__() -- size of T in memory, in bytes
 |  
 |  count(...)
 |      T.count(value) -> integer -- return number of occurrences of value
 |  
 |  index(...)
 |      T.index(value, [start, [stop]]) -> integer -- return first index of value.
 |      Raises ValueError if the value is not present.
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  __new__ = <built-in method __new__ of type object>
 |      T.__new__(S, ...) -> a new object with type S, a subtype of T

>>> t1.index(2)
1
>>> t1
(1, 2, 3)
>>> t1 += (4,5,6)
>>> t1
(1, 2, 3, 4, 5, 6)
>>> id(t1)
48055552
>>> t1 += (7,8)
>>> id(t1)
48238960
>>> t2=(10,20,30,40)
>>> a1,a2,a3,a4=t2
>>> a1
10
>>> a2
20
>>> a3
30
>>> a4
40
>>> # Unpacking
>>> t3 = a1,a2,a3,a4
>>> t3
(10, 20, 30, 40)
>>> t2=(10,20,30,40)
>>> list(t3)
[10, 20, 30, 40]
>>> type(t3)
<class 'tuple'>
>>> t4
Traceback (most recent call last):
  File "<pyshell#181>", line 1, in <module>
    t4
NameError: name 't4' is not defined
>>> t4 = list(t3)
>>> type(t4)
<class 'list'>
>>> l5
Traceback (most recent call last):
  File "<pyshell#184>", line 1, in <module>
    l5
NameError: name 'l5' is not defined
>>> l5 = tuple(l2)
>>> type(l5)
<class 'tuple'>
>>> l5
(1, 2, 3, [4, 10, 6])
>>> d = {}
>>> type(d)
<class 'dict'>
>>> d1 = {Id:101,Name:"Aishwarya"}
Traceback (most recent call last):
  File "<pyshell#190>", line 1, in <module>
    d1 = {Id:101,Name:"Aishwarya"}
NameError: name 'Id' is not defined
>>> d1 = {"Id":101,"Name":"Aishwarya","Age":21}
>>> d1
{'Name': 'Aishwarya', 'Age': 21, 'Id': 101}
>>> d2 = {"Id":101,"Id":102,"Name":"Aishwarya","Age":21}
>>> d2
{'Name': 'Aishwarya', 'Age': 21, 'Id': 102}
>>> len(d1)
3
>>> d1.keys()
dict_keys(['Name', 'Age', 'Id'])
>>> d1.keys(1)
Traceback (most recent call last):
  File "<pyshell#197>", line 1, in <module>
    d1.keys(1)
TypeError: keys() takes no arguments (1 given)
>>> list(d1.keys())[1]
'Age'
>>> d1.values()
dict_values(['Aishwarya', 21, 101])
>>> list(d1.values())[1]
21
>>> range(1,10)
range(1, 10)
>>> for r in range(1,5)
SyntaxError: invalid syntax
>>> r1 = range(3,10)
>>> type(r1)
<class 'range'>
>>> for x in r1:
	print(x)

	
3
4
5
6
7
8
9
>>> for k in d1.keys():
	print(k)

	
Name
Age
Id
>>> for k in d1.keys():
	print(k,d1[k])

	
Name Aishwarya
Age 21
Id 101
>>> d1.items()
dict_items([('Name', 'Aishwarya'), ('Age', 21), ('Id', 101)])
>>> d1.has_key()
Traceback (most recent call last):
  File "<pyshell#216>", line 1, in <module>
    d1.has_key()
AttributeError: 'dict' object has no attribute 'has_key'
>>> d1.get('Id')
101
>>> d1['Id']
101
>>> d1.get('abc',120)
120
>>> d1.get('Id',120)
101
>>> l1 = [1,2,2,3,4,5,3]
>>> l1
[1, 2, 2, 3, 4, 5, 3]
>>> s1 = set()l1
SyntaxError: invalid syntax
>>> s1 = set(l1)
>>> s1
{1, 2, 3, 4, 5}
>>> s2 = {5,1,3,7,4,3,2}
>>> s2
{1, 2, 3, 4, 5, 7}
>>> 
