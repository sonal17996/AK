def add(n1,n2):
    res = n1+n2
    return res

n1 = int(input("Enter a number: "))
n2 = int(input("Enter a number: "))
res = add(n1,n2)

print("Addition of {0} and {1} is {2}".format(n1,n2,res))
