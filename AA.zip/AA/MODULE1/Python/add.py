"""def add(*param):
    res = 0
    for i in param:
        res = res+i
    return res


res1 = add(10,20,30)
res2 = add(10,20,30,40)

print(res1,"\t",res2)"""

"""def add(*param):
    l1 = list(param)
    res = sum(l1)
    return res

res1 = add(10,20,30)
res2 = add(10,20,30,40)

print(res1,"\t",res2)"""

"""def func(id1,age,name="Unknown"):
    print("ID:",id1," Name:",name," Age:",age)

func(id1=1,name="Aishwarya",age=21)
func(name="Sonal",id1=2,age=22)
func(age=23,id1=3)"""

"""def getEmpDetails(**details):
    
    print("I'm {1}, my empID is {0}, I'm {2} years old".format(details.get('id'),details.get('name'),details.get('age')))

getEmpDetails(id=123,age=21,name="Aishwarya")

#help(getEmpDetails)"""

def getEmp(details):
    print(type(details))
    print("Id is {0}, name is {1}, I'm {2} years old".format(details.get('id'),details.get('name'),details.get('age')))
    details['name']="Aishwarya"

EmpD

add=lambda x,y:x+y
res = add(10,20)
print(res)
    
