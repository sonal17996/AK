
id = 101
name = "Aishwarya"
salary = 20000

"""f = open("Emps.txt",'w')
f.write(str(id)+","+name+","+str(salary))           #format
f.close()

print("Details written into file..")"""


f = open("Emps.txt",'r')
data = f.read()
f.close()

x = data.split(',')
id = x[0]
name = x[1]
salary = x[2]

print("Details read from file..")
print("Id: {0}, Name: {1}, Salary: {2}".format(id,name,salary))


>>> ================================ RESTART ================================
>>> 
Details written into file..
>>> ================================ RESTART ================================
>>> 
Details read from file..
>>> ================================ RESTART ================================
>>> 
Details read from file..
101,Aishwarya,20000
>>> ================================ RESTART ================================
>>> 
Details read from file..
Id: 101, Name: Aishwarya, Salary: 20000
>>> 
