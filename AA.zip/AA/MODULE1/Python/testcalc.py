"""import calc

res = calc.add(10,20)
print(res)

import calc as c

res = calc.sub(10,20)
print(res)

from calc import add,sub

res = add(10,20)
print(res)

res1 = mul(10,20)
print(res1)"""

from calc import *

res = add(10,20)
print(res)

res1 = mul(10,20)
print(res1)
