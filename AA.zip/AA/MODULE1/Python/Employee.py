def Test():
    print("This is procedure from Employee module")

class Employee:
    
    """def __init__(self):
        self.empId = 101
        self.empName = "Aishwarya"
        self.salary = 20000"""

    def __init__(self,empId,empName,empSalary):
        self.empId = empId
        self.empName = empName
        self.empSalary = empSalary
        
    def setDetails1(self,empId,empName):
        self.empId = empId
        self.empName = empName

    def setDetails2(self,empName,empSalary):
        self.empName = empName
        self.empSalary = empSalary

    def displayDetails(self):
        print("Emp Id: {0},Emp Name: {1},Emp Salary: {2}".format(self.empId,self.empName,self.empSalary))
    
    
