def max_in_list(params):
    max=0
    for i in params:
        if i>max:
            max=i
    return max
li=[]
print("Enter a list of numbers(enter -1 to stop adding elements)")
w=int(input())
while(w!=-1):
    li.append(w)
    w=int(input())
long=max_in_list(li)
print("Maximum number in the list is",long)
