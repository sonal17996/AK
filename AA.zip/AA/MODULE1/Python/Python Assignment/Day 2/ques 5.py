def filter_long_words(words,n):
    li=[]
    for i in words:
        if len(i)>n:
            li.append(i)

    print("List of words greater than,",str(n))
    print(li)
li=[]
print("Enter a integer")
n=int(input())
print("Enter a list of words (enter @ to stop adding elements)")
w=input()
while(w!='@'):
    li.append(w)
    w=input()
filter_long_words(li,n)
