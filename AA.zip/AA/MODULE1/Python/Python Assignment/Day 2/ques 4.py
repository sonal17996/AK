def find_longest_word(words):
    max=0;
    n=len(words)
    for i in range(0,n-1):
        t1=len(words[i])
        t2=len(words[i+1])
        if(max<t1):
            max=t1
        elif(max<t2):
            max=t2
    return max
li=[]
l2=[]
print("Enter a list of words (enter @ to stop adding elements)")
w=input()
while(w!='@'):
    li.append(w)
    l2.append(len(w))
    w=input()
print(li)
long=find_longest_word(li)
print(long)
long=lambda l2:max(l2)
    
print(long(l2))
