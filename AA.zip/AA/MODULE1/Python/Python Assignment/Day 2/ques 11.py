from anant.mathematics import*
a=[1,2,3]
b=[4,5,6,7,8]
c=Add(a,b)
d=Sub(a,b)
print("Addition :",c)
print("Subtraction :",d)
mini=min(c)
maxim=max(c)
print("Minimum and Maximum of addition is ",mini,maxim,"respectively")
mini=min(d)
maxim=max(d)
print("Minimum and Maximum of Subtraction is ",mini,maxim,"respectively")
print("sorted addition list",sorting(c))
print("sorted subtraction list",sorting(d))
