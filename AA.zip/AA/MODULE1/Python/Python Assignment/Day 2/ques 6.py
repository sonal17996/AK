def palindrome(word):
    word=word.lower()
    word=word.replace(" ","")
    word=word.replace(',',"")
    word=word.replace("'","")
    flag=True
    for i in range(0,len(word)//2):
        if word[i]!=word[(len(word)-1)-i]:
            flag=False
            break
    if flag==True:
        print("String is Palindrome")
    else:
        print("String is not Palindrome")
w=input("Enter a sentence")
palindrome(w)
