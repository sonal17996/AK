def pangram(word):
    word=word.lower()
    word=word.replace(" ","")
    li=[]
    for i in word:
        li.append(i)
    s=set(li)
    if(len(s)==26):
        print("pangram")
    else:
        print("Not Pangram")
word=input("Enter a sentence to check pangram")
pangram(word)
