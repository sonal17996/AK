def Add(a,b):
    c=[]
    if len(a)<len(b):
        for i in range(0,len(a)):
            c.append(a[i]+b[i])
        for i in range(len(c),len(b)):
            c.append(b[i])
    if len(b)<len(a):
        for i in range(0,len(b)):
            c.append(a[i]+b[i])
        for i in range(len(c),len(a)):
            c.append(b[i])
    return c
def Sub(a,b):
    c=[]
    if len(a)<len(b):
        for i in range(0,len(a)):
            c.append(a[i]-b[i])
        for i in range(len(c),len(b)):
            c.append(b[i])
    if len(b)<len(a):
        for i in range(0,len(b)):
            c.append(a[i]-b[i])
        for i in range(len(c),len(a)):
            c.append(b[i])
    return c
    
def sorting(a):
    a.sort()
    return a
