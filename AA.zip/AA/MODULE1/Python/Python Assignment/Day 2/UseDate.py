import Date
from datetime import date
class UseDate:
    today=date.today();
    d1=Date.Date(today.day,today.month,today.year)
    d1.printdate()
    
   
