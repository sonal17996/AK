x=input("Enter a String")
y=x.swapcase()
print(y)
    
