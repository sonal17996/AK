num1=int(input("Enter first number"))
num2=int(input("Enter second number"))
res=num1+num2
if res>=0:
    print("Addition is positive")
else:
    print("Addition is negative")
