l1=[]
l2=[]
flag=False
print("Enter first list(type @ to stop adding to the list)")
a=input("Enter the value")
while a!='@':
    l1.append(a)
    a=input("Enter the value")
print("Enter Second list(type @ to stop adding to the list)")
a=input("Enter the value")
while a!='@':
    l2.append(a)
    a=input("Enter the value")
for i in l1:
    for j in l2:
        if i==j:
            flag=True
if flag==True:
    print("True")
else:
    print("False")
