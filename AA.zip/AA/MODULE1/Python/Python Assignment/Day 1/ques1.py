name=input("Enter your Name")
print("Hello,",name)
