x=input("Enter the value to check its membership in the list")
li=[]
flag=False
print("1. Add elements to list")
print("2. Stop adding")
a=int(input("Enter the value"))
while(a==1):
    b=input("Enter the value for the list")
    li.append(b)
    print("1. Add elements to list")
    print("2. Stop adding")
    a=int(input("Enter the value"))
for i in li:
    if i==x:
        flag=True
        break
if flag==True:
    print("True")
else:
    print("False")
