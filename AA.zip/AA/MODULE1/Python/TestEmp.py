
import Employee
Employee.Test()

#e1 = Employee.Employee()
e2 = Employee.Employee(11,'A',25000)
#print("Emp Id: {0}, Emp Salary: {1}".format(e1.empId,e1.empSalary))

#print("Emp Id: {0}, Emp Name: {1}, Emp Salary: {2}".format(e1.empId,e1.empName,e1.empSalary))

#e1.displayDetails()
e2.displayDetails()

e3 = Employee.Employee()
e3.setDetails1(101,'B')
print("Emp Id: {0}, Emp Salary: {1}".format(e3.empId,e3.empName))
